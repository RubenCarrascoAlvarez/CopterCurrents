Download the external library 'deg2utm' and save it to this folder
to extend CopterCurrents capabilities:

download url: 	https://www.mathworks.com/matlabcentral/fileexchange/10915-deg2utm

Author: Rafael Palacios, Universidad Pontificia Comillas, Madrid, Spain 

Matlab function to convert lat/lon vectors into UTM coordinates (WGS84).


