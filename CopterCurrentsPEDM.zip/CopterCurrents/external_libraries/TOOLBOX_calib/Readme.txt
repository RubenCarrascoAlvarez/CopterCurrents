Download the external library 'Camera Calibration Toolbox' and save it to this folder
to extend CopterCurrents capabilities:

download url: 	http://www.vision.caltech.edu/bouguetj/calib_doc/download/index.html
Toolbox manual: http://www.vision.caltech.edu/bouguetj/calib_doc/

Author: Jean-Yves Bouguet,jean-yves.bouguet@intel.com. 

Caltech Matlab library used for Camera calibration, and camera data projection, also implementent in OpenCV.
