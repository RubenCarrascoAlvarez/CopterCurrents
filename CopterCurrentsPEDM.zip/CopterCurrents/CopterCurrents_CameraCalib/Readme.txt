Copy your the CopterCurrents camera calibration files in this folder.
